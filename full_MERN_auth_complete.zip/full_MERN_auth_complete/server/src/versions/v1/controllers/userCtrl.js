/* eslint-disable no-underscore-dangle */
const axios = require("axios");
const jwt = require("jsonwebtoken");
const {
 google
} = require("googleapis");
const {
 checkPassword, hashPassword
} = require("../utils/bcrypt");
const sendMail = require("./sendMail");

const Users = require("../models/userModel");

const {
 OAuth2
} = google.auth;

const client = new OAuth2(process.env.MAILING_SERVICE_CLIENT_ID);

const {
 CLIENT_URL
} = process.env;

const {
 realtimeBatteryUpdate: constants
} = require("../constants");

const validateEmail = (email) => {
  /* eslint no-useless-escape: "warn" */
  const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
};

const createActivationToken = (payload) => jwt.sign(payload, process.env.ACTIVATION_TOKEN_SECRET, {
    expiresIn: "5m"
  });

const createAccessToken = (payload) => jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET, {
    expiresIn: "15m"
  });

const createRefreshToken = (payload) => jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET, {
    expiresIn: "7d"
  });

const userCtrl = {
  register: async (req, res) => {
    try {
      const {
 name, email, password
} = req.body;

      if (!name || !email || !password) {
        return res.status(400).json({
          msg: constants.form_validation.incompleteFields.ALL_FIELDS_REQUIRED
        });
      }

      if (!validateEmail(email)) {
        return res.status(400).json({
          msg: constants.form_validation.email.INVALID_EMAIL
        });
      }

      const user = await Users.findOne({
        email
      });
      if (user) {
        return res.status(400).json({
          msg: constants.form_validation.email.EMAIL_ALREADY_EXIST
        });
      }

      if (password.length < 6) {
        return res.status(400).json({
          msg: constants.form_validation.password.MUST_LENGTH
        });
      }

      const passwordHash = await hashPassword(password);

      const newUser = {
        name,
        email,
        password: passwordHash
      };

      const activationToken = createActivationToken(newUser);

      const url = `${CLIENT_URL}/user/activate/${activationToken}`;
      // TODO: JUST FOR TESTING, need to remove
      // sendMail(email, url, 'Verify your email address');
      console.log(url);

      res.status(200).json({
        msg: "Register Success! Please activate your account. Activation Link Sent On Your Mail. Please Check Your Email within 5 minutes."
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  activateEmail: async (req, res) => {
    try {
      const {
 activationToken
} = req.body;
      const user = jwt.verify(activationToken, process.env.ACTIVATION_TOKEN_SECRET);

      const {
 name, email, password
} = user;

      const check = await Users.findOne({
 email
});
      if (check) {
        return res.status(400).json({
          msg: constants.form_validation.email.EMAIL_ALREADY_EXIST
        });
      }

      const newUser = new Users({
        name,
        email,
        password
      });

      await newUser.save();

      res.status(200).json({
        msg: constants.auth.ACCOUNT_ACTIVATED
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  login: async (req, res) => {
    try {
      const {
 email, password
} = req.body;
      const user = await Users.findOne({
        email
      });
      if (!user) {
        return res.status(400).json({
          msg: constants.form_validation.email.EMAIL_NOT_EXIST
        });
      }

      const isMatch = await checkPassword(password, user.password);
      if (!isMatch) {
        return res.status(400).json({
          msg: constants.form_validation.password.INCORRECT_PASSWORD
        });
      }

      const refreshToken = createRefreshToken({
        id: user._id
      });

      res.status(200).json({
        msg: constants.auth.LOGIN_SUCCESS,
        refresh_token: {
          token: refreshToken,
          name: "refreshtoken",
          httpOnly: true,
          path: "/api/v1/user/refresh_token",
          maxAge: 7 // 7 * 24 * 60 * 60 * 1000, // 7 days
        }
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  getAccessToken: (req, res) => {
    try {
      const rfToken = req.body.token;
      if (!rfToken) {
        return res.status(400).json({
          msg: "Please login now!!"
        });
      }

      jwt.verify(rfToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
        if (err) {
          return res.status(400).json({
            msg: "Please login now!"
          });
        }

        const accessToken = createAccessToken({
          id: user.id
        });
        res.status(200).json({
          accessToken
        });
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  forgotPassword: async (req, res) => {
    try {
      const {
 email
} = req.body;
      const user = await Users.findOne({
        email
      });
      if (!user) {
        return res.status(400).json({
          msg: constants.form_validation.email.EMAIL_NOT_EXIST
        });
      }

      const accessToken = createAccessToken({
        id: user._id
      });

      const url = `${CLIENT_URL}/user/reset/${accessToken}`;

      // TODO: JUST FOR TESTING, need to remove
      // sendMail(email, url, "Reset your password");
      console.log(url);
      res.status(200).json({
        msg: "Password Rest Link Sent On Your Mail, please check your email."
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  resetPassword: async (req, res) => {
    try {
      const {
 password
} = req.body;
      const passwordHash = await hashPassword(password);

      await Users.findOneAndUpdate(
        {
          _id: req.user.id
        },
        {
          password: passwordHash
        }
      );

      res.status(200).json({
        msg: "Password successfully changed!"
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  getUserInfor: async (req, res) => {
    try {
      const user = await Users.findById(req.user.id).select("-password");

      res.status(200).json(user);
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  getUsersAllInfor: async (req, res) => {
    try {
      const users = await Users.find().select("-password");

      res.status(200).json(users);
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  logout: async (req, res) => {
    try {
      res.clearCookie("refreshtoken", {
        path: "/api/v1/user/refresh_token"
      });
      return res.status(200).json({
        msg: constants.auth.LOGOUT_SUCCESS
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  updateUser: async (req, res) => {
    try {
      const {
 name, avatar
} = req.body;
      await Users.findOneAndUpdate(
        {
          _id: req.user.id
        },
        {
          name,
          avatar
        }
      );

      res.status(200).json({
        msg: "Update Success!"
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  updateUsersRole: async (req, res) => {
    try {
      const {
 role
} = req.body;

      await Users.findOneAndUpdate(
        {
          _id: req.params.id
        },
        {
          role
        }
      );

      res.status(200).json({
        msg: "Update Success!"
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  },
  deleteUser: async (req, res) => {
    try {
      await Users.findByIdAndDelete(req.params.id);

      res.status(200).json({
        msg: "Deleted Success!"
      });
    } catch (err) {
      return res.status(500).json({
        msg: err.message
      });
    }
  }
//   googleLogin: async (req, res) => {
//     try {
//       const {
//  tokenId
// } = req.body;

//       const verify = await client.verifyIdToken({
//         idToken: tokenId,
//         audience: process.env.MAILING_SERVICE_CLIENT_ID
//       });

//       const {
//         // eslint-disable-next-line camelcase
//         email_verified,
//         email,
//         name,
//         picture
//       } = verify.payload;

//       const password = email + process.env.GOOGLE_SECRET;

//       // const passwordHash = await bcrypt.hash(password, 12);
//       const passwordHash = await hashPassword(password);

//       // eslint-disable-next-line camelcase
//       if (!email_verified) {
//         return res.status(400).json({
//           msg: "Email verification failed."
//         });
//       }

//       const user = await Users.findOne({
//         email
//       });

//       if (user) {
//         // const isMatch = await bcrypt.compare(password, user.password);
//         const isMatch = await checkPassword(password, user.password);
//         if (!isMatch) {
//           return res.status(400).json({
//             msg: constants.form_validation.password.INCORRECT_PASSWORD
//           });
//         }

//         const refreshToken = createRefreshToken({
//           id: user._id
//         });
//         res.cookie("refreshtoken", refreshToken, {
//           httpOnly: true,
//           path: "/api/v1/user/refresh_token",
//           maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
//         });

//         res.json({
//           msg: constants.auth.LOGIN_SUCCESS
//         });
//       } else {
//         const newUser = new Users({
//           name,
//           email,
//           password: passwordHash,
//           avatar: picture
//         });

//         await newUser.save();

//         const refreshToken = createRefreshToken({
//           id: newUser._id
//         });
//         res.cookie("refreshtoken", refreshToken, {
//           httpOnly: true,
//           path: "/api/v1/user/refresh_token",
//           maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
//         });

//         res.json({
//           msg: constants.auth.LOGIN_SUCCESS
//         });
//       }
//     } catch (err) {
//       return res.status(500).json({
//         msg: err.message
//       });
//     }
//   },
//   facebookLogin: async (req, res) => {
//     try {
//       const {
//  accessToken, userID
// } = req.body;

//       const URL = `https://graph.facebook.com/v2.9/${userID}/?fields=id,name,email,picture&access_token=${accessToken}`;

//       const data = await axios(URL)
//         .then((dataRes) => dataRes.json())
//         .then((dataRes) => dataRes);

//       const {
//  email, name, picture
// } = data;

//       const password = email + process.env.FACEBOOK_SECRET;

//       // const passwordHash = await bcrypt.hash(password, 12);
//       const passwordHash = await hashPassword(password);

//       const user = await Users.findOne({
//         email
//       });

//       if (user) {
//         // const isMatch = await bcrypt.compare(password, user.password);
//         const isMatch = await checkPassword(password, user.password);
//         if (!isMatch) {
//           return res.status(400).json({
//             msg: constants.form_validation.password.INCORRECT_PASSWORD
//           });
//         }

//         const refreshToken = createRefreshToken({
//           id: user._id
//         });
//         res.cookie("refreshtoken", refreshToken, {
//           httpOnly: true,
//           path: "/api/v1/user/refresh_token",
//           maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
//         });

//         res.json({
//           msg: constants.auth.LOGIN_SUCCESS
//         });
//       } else {
//         const newUser = new Users({
//           name,
//           email,
//           password: passwordHash,
//           avatar: picture.data.url
//         });

//         await newUser.save();

//         const refreshToken = createRefreshToken({
//           id: newUser._id
//         });
//         res.cookie("refreshtoken", refreshToken, {
//           httpOnly: true,
//           path: "/api/v1/user/refresh_token",
//           maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
//         });

//         res.json({
//           msg: constants.auth.LOGIN_SUCCESS
//         });
//       }
//     } catch (err) {
//       return res.status(500).json({
//         msg: err.message
//       });
//     }
//   }
};

module.exports = userCtrl;
