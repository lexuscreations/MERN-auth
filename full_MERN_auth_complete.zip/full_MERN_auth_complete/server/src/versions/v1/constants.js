module.exports = Object.freeze({
  realtimeBatteryUpdate: {
    form_validation: {
      email: {
        EMAIL_NOT_EXIST: "This email does not exist! Or Activate your account",
        EMAIL_ALREADY_EXIST: "This email already exists.",
        INVALID_EMAIL: "Invalid email."
      },
      password: {
        MUST_LENGTH: "Password must be at least 6 characters.",
        INCORRECT_PASSWORD: "Password is incorrect."
      },
      incompleteFields: {
        ALL_FIELDS_REQUIRED: "Please fill in all fields."
      }
    },
    auth: {
      ACCESS_DENIED_ADMIN: "Admin resources access denied.",
      AUTHENTICATION_FAILED: "Invalid Authentication.",
      LOGIN_SUCCESS: "Login success!",
      LOGOUT_SUCCESS: "Logged out.",
      ACCOUNT_ACTIVATED: "Account has been activated! Now You Can Login!"
    },
    fileUpload: {
      FILE_NOT_FOUND_IN_REQUEST: "No files were uploaded",
      SIZE_EXCEEDED: "Size too large.",
      FORMATE_INCORRECT: "File format is incorrect."
    }
  }
});
