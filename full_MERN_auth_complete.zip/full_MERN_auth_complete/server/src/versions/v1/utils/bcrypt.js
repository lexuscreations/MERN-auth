/* eslint-disable no-return-await */
const bcrypt = require("bcrypt");
const path = require("path");

const {
BCRYPT: {
BCRYPT_ROUND
}
} = require(path.join(global.rootDir, "./config/appConfig"));

module.exports = {
    hashPassword: async (password) => await bcrypt.hash(password, BCRYPT_ROUND).catch((error) => {
        throw new Error(error);
    }),
    checkPassword: async (givenPassword, userPassword) => await bcrypt.compare(givenPassword, userPassword).catch((error) => {
        throw new Error(error);
    })
};
