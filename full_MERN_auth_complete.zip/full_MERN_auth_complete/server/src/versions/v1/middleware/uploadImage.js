const fs = require("fs");
const {
 realtimeBatteryUpdate: constants
} = require("../constants");

const removeTmp = (path) => {
  fs.unlink(path, (err) => {
    if (err) throw err;
  });
};

module.exports = async (req, res, next) => {
  try {
    if (!req.files || Object.keys(req.files).length === 0) {
      return res.status(400).json({
        msg: constants.fileUpload.FILE_NOT_FOUND_IN_REQUEST
      });
    }

    const {
 file
} = req.files;

    if (file.size > 1024 * 1024) {
      removeTmp(file.tempFilePath);
      return res.status(400).json({
        msg: constants.fileUpload.SIZE_EXCEEDED
      });
    } // 1mb

    if (file.mimetype !== "image/jpeg" && file.mimetype !== "image/png") {
      removeTmp(file.tempFilePath);
      return res.status(400).json({
        msg: constants.fileUpload.FORMATE_INCORRECT
      });
    }

    next();
  } catch (err) {
    return res.status(500).json({
      msg: err.message
    });
  }
};
