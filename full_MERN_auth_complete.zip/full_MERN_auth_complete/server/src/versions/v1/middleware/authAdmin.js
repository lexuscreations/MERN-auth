const Users = require("../models/userModel");

const {
 realtimeBatteryUpdate: constants
} = require("../constants");

const authAdmin = async (req, res, next) => {
  try {
    const user = await Users.findOne({
 _id: req.user.id
});

    if (user.role !== 1) {
 return res.status(500).json({
 msg: constants.auth.ACCESS_DENIED_ADMIN
});
}

    next();
  } catch (err) {
    return res.status(500).json({
 msg: err.message
});
  }
};

module.exports = authAdmin;
