"use strict";

const router = require("express").Router();

const routesInit = () => {
  router.use("/v1", require("./versions/v1/routes"));
  return router;
};

// const socketsInit = (server) => require("./versions/v1/sockets")(server);

module.exports = {
  routesInit
  // socketsInit
};
