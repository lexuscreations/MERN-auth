"use strict";

const express = require("express");
const cookieParser = require("cookie-parser");
const fileUpload = require("express-fileupload");
const path = require("path");
const mongoose = require("mongoose");
const fs = require("fs");
const morgan = require("morgan");

const {
 SERVER: serverConfig
} = require(path.join(global.rootDir, "./config/appConfig"));

const {
 DB: {
 MONGODB_URL
}
} = require("../config/appConfig");

const router = express.Router();

const {
 cors, appConfig
} = require("../config");

const {
  myColorCLILib
 } = require("../lib");

mongoose.connect(
  MONGODB_URL,
  {
    useNewUrlParser: true,
    useUnifiedTopology: true
  },
  (err) => {
    if (err) throw err;
    myColorCLILib("Success", "Connected to mongodb");
  }
);

module.exports = (server) => {
  router.use(
    express.urlencoded({
      extended: true,
      limit: "50mb"
    })
  );

  router.use(cookieParser());

  router.use(
    fileUpload({
      limits: {
   fileSize: 5 * 1024 * 1024 // 5mb
  },
      useTempFiles: true,
      tempFileDir: path.join(global.rootDir, "./upload/temp")
    })
  );

  router.use(
    express.json({
      limit: "16mb"
    })
  );

  router.use(cors.serverCors());

  if (serverConfig.loggerIn === "file") {
      morgan.token("date", (req, res, tz) => {
        const date = Date();
        return date.toLocaleString(undefined, {
                timeZone: "Asia/Kolkata"
              });
      });
      router.use(morgan("combined", {
          stream: fs.createWriteStream(`${global.rootDir}/logs/access.log`, {
            flags: "a"
          })
      }));
  } else {
      router.use(morgan("dev")); // log to console on development
  }

  // if (process.env.NODE_ENV === 'production') {
  //   app.use(express.static('client/build'));
  //   app.get('*', (req, res) => {
  //     res.sendFile(path.join(__dirname, 'client', 'build', 'index.html'));
  //   });
  // }

  router.use("/api", require("./app").routesInit());
  // require("./app").socketsInit(server);

  router.use((req, res, next) => {
    const error = new Error(`404_Not Found - ${req.originalUrl}`);
    res.status(404);
    next(error);
  });

  router.use((err, req, res, next) => {
    const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
    res.status(statusCode);
    res.json({
      isError: true,
      message: "Not Found!",
      msg: err.message,
      data: appConfig.showDevLogsAndResponse
        ? err.stack
        : {
            //
          },
      err,
      errorCode: statusCode,
      success: false
    });
  });

  return router;
};
