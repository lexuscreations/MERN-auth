"use strict";

const serverStarting = process.hrtime();

const path = require("path");

global.rootDir = path.join(process.cwd());

const envFile = require("dotenv").config();

const cors = require("cors");

if (envFile.error) throw new Error("env file is missing!");

const app = require("express")();

app.use(cors());

const server = require("http").createServer(app);

const {
 myColorCLICustom
} = require("./lib");

const {
 appConfig
} = require("./config");

app.use("/", require("./src/server")(server));

const GET_PORT_FROM_ARGS_FN = () => {
  process.argv.forEach((val) => {
    if (val.toLowerCase().search("port") !== -1 && val.slice(0, 4).toLowerCase() === "port") {
      return parseInt(val.split("=")[1], 10);
    }
  });
};

const PORT = parseInt(GET_PORT_FROM_ARGS_FN() || process.env.PORT || appConfig.SERVER.PORT || 5000, 10);

server.listen(PORT, () => {
  const serverStarted = process.hrtime(serverStarting);
  process.stdout.write(
    `${myColorCLICustom.fg.blue}Info: ${myColorCLICustom.fg.cyan}Server started in ${myColorCLICustom.fg.magenta}${myColorCLICustom.reverse}${(
      (serverStarted[0] * 1e9 + serverStarted[1])
      / 1e9
    ).toFixed(2)}${myColorCLICustom.reset}${myColorCLICustom.fg.cyan} seconds and listening on port: ${myColorCLICustom.reverse}${
      myColorCLICustom.fg.magenta
    }${PORT}${myColorCLICustom.fg.cyan}${myColorCLICustom.reset} ${myColorCLICustom.fg.cyan}| ${myColorCLICustom.fg.magenta}loggedAt:${
      myColorCLICustom.fg.cyan
    }${myColorCLICustom.underscore} ${new Date()} ${myColorCLICustom.reset}${myColorCLICustom.fg.green}${
      process.env.PING_ENV ? "And .env also found!" : "But .env not found!"
    }${myColorCLICustom.reset}\n`
  );
});

process.on("uncaughtException", (err) => {
  console.log({
    "err.name": err.name,
    "err.message": err.message
  });
  console.log("UNCAUGHT EXCEPTION! 💥 Shutting down...");
  process.exit(1);
});

process.on("unhandledRejection", (err) => {
  console.log({
    "err.name": err.name,
    "err.message": err.message
  });
  console.log("UNHANDLED REJECTION! 💥 Shutting down...");
  process.exit(1);
});

["exit", "SIGTERM", "SIGUSR1", "SIGUSR2", "SIGINT"].forEach((eventType) => {
  // TODO: need to handle some cleanUp/backup hear for future
  process.on(eventType, (err) => {
    server.close(() => {
      if (eventType === "SIGINT") console.log("Process terminated");
      console.log("Byeeeee....");
      process.exit(0);
    });
  });
});
