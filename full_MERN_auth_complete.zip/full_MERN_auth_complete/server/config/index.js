"use strict";

const cors = require("./cors");
const appConfig = require("./appConfig");

module.exports = {
  cors,
  appConfig
};
