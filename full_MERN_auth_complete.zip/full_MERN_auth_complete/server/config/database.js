const {
 MONGODB_URL
} = process.env;

module.exports = {
    MONGODB_URL: MONGODB_URL || "mongodb://localhost:27017"
};
