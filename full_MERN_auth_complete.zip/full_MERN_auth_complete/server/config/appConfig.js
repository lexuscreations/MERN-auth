"use strict";

require("dotenv").config();
const DB = require("./database");

const {
  PORT,
  NODE_ENV,
  ACCESS_TOKEN_SECRET,
  REFRESH_TOKEN_SECRET,
  ACTIVATION_TOKEN_SECRET,
  SERVER_URL,
  CLIENT_URL,
  BCRYPT_ROUND
} = process.env;

module.exports = {
  SERVER: {
    PORT: parseInt(PORT || 5000, 10),
    NODE_ENV: NODE_ENV || "development",
    SERVER_URL: SERVER_URL || "http://localhost:5000",
    loggerIn: "file" // file, console
  },
  CLIENT: {
    CLIENT_URL: CLIENT_URL || "http://localhost:3000"
  },
  DB,
  JWT: {
    ACCESS_TOKEN_SECRET,
    REFRESH_TOKEN_SECRET,
    ACTIVATION_TOKEN_SECRET
  },
  BCRYPT: {
    BCRYPT_ROUND: parseInt(BCRYPT_ROUND || 10, 10)
  },
  showDevLogsAndResponse: false
};
