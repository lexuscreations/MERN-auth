"use strict";

const {
  CLIENT: { CLIENT_URL }
} = require("./appConfig");

const serverCors = () => (req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, timeZone");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, PATCH");
  next();
};

const socketCors = {
  origin: CLIENT_URL,
  methods: ["GET", "POST"]
};

module.exports = {
  serverCors,
  socketCors
};
