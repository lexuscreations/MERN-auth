import { useSelector } from 'react-redux';

const Home = () => {
  const auth = useSelector((state) => state.auth);

  return (
    <>
      <div className="home_page">
        <h2>Hello {auth.user.name || 'EveryOne'}!</h2>
        <div className="hero-image">
          <div className="hero-text">
            <h1 style={{ fontSize: '50px' }}>Live Battery Indicator</h1>
            <p>Realtime Battery Update</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
