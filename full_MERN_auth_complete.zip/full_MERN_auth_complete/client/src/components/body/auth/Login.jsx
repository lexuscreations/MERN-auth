import axios from 'axios';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Login as LoginIcon } from '@mui/icons-material';

import config from '../../../config/app.config';
import { login } from '../../../redux/authSlice';
import { isEmpty } from '../../utils/validation/Validation';

const configToast = config.CONFIG_TOAST;
axios.defaults.baseURL = config.REACT_APP_SERVER_URI;

const initialState = {
  email: '',
  password: '',
};

const Login = () => {
  const [user, setUser] = useState(initialState);
  const { email, password } = user;
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChangeInput = (e) =>
    setUser({ ...user, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isEmpty(email) || isEmpty(password))
        return toast.error(
          'Please Fill Valid Data In All The Fields!',
          configToast
        );

      const res = await axios.post('/user/login', { email, password });
      toast.success(res.data.msg, configToast);
      localStorage.setItem('firstLogin', true);
      localStorage.setItem('token', res.data.refresh_token.token);
      dispatch(login());
      navigate('/');
    } catch (err) {
      err.response.data.msg && toast.error(err.response.data.msg, configToast);
    }
  };

  return (
    <div className="d-flex-center" style={{ minHeight: '80vh' }}>
      <div className="authFormContainer">
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="email">Email Address</label>
            <input
              type="text"
              placeholder="Enter email address"
              id="email"
              value={email}
              name="email"
              onChange={handleChangeInput}
            />
          </div>

          <div>
            <label htmlFor="password">Password</label>
            <input
              type="password"
              placeholder="Enter password"
              id="password"
              value={password}
              name="password"
              onChange={handleChangeInput}
            />
          </div>

          <Button
            type="submit"
            variant="contained"
            color="inherit"
            endIcon={<LoginIcon />}
          >
            Login
          </Button>
          <Link to="/forgot_password">
            <Typography style={{ color: 'crimson', marginTop: '0.6rem' }}>
              Forgot password?
            </Typography>
          </Link>
        </form>

        <p style={{ margin: '10px 0' }}>
          Don't have an account?{' '}
          <Link to="/register" style={{ fontWeight: '600' }}>
            Register
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
