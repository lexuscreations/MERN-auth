import axios from 'axios';
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { toast } from 'react-toastify';

import Button from '@mui/material/Button';
import PasswordLockResetIcon from '@mui/icons-material/LockReset';

import { isLength, isMatch, isEmpty } from '../../utils/validation/Validation';
import config from '../../../config/app.config';

const configToast = config.CONFIG_TOAST;

const initialState = {
  password: '',
  cf_password: '',
};

const ResetPassword = () => {
  const [data, setData] = useState(initialState);
  const { password, cf_password } = data;
  const { token } = useParams();

  const handleChangeInput = (e) =>
    setData({ ...data, [e.target.name]: e.target.value });

  const handleResetPass = async () => {
    if (isEmpty(password) || isEmpty(cf_password))
      return toast.error(
        'Please Fill Valid Data In All The Fields!',
        configToast
      );

    if (isLength(password))
      return toast.error(
        'Password must be at least 6 characters.',
        configToast
      );

    if (!isMatch(password, cf_password))
      return toast.error('Password did not match.', configToast);

    try {
      const res = await axios.post(
        '/user/reset',
        { password },
        {
          headers: { Authorization: token },
        }
      );

      return toast.success(res.data.msg, configToast);
    } catch (err) {
      err.response.data.msg && toast.error(err.response.data.msg, configToast);
    }
  };

  useEffect(() => {
    axios.defaults.baseURL = config.REACT_APP_SERVER_URI;
  }, []);

  return (
    <div className="d-flex-center" style={{ minHeight: '80vh' }}>
      <div className="authFormContainer">
        <h2>Reset Your Password</h2>

        <div className="row">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            name="password"
            id="password"
            value={password}
            onChange={handleChangeInput}
            placeholder="Enter New Password"
          />

          <label htmlFor="cf_password">Confirm Password</label>
          <input
            type="password"
            name="cf_password"
            placeholder="ReEnter New Password"
            id="cf_password"
            value={cf_password}
            onChange={handleChangeInput}
          />

          <Button
            type="submit"
            variant="contained"
            color="inherit"
            endIcon={<PasswordLockResetIcon />}
            onClick={handleResetPass}
          >
            Reset Password
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
