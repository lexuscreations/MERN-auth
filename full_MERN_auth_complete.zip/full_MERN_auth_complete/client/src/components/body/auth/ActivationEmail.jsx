import axios from 'axios';
import { toast } from 'react-toastify';
import { useParams } from 'react-router-dom';

import config from '../../../config/app.config';
const configToast = config.CONFIG_TOAST;
axios.defaults.baseURL = config.REACT_APP_SERVER_URI;

const ActivationEmail = () => {
  const { activation_token: activationToken } = useParams();

  if (activationToken) {
    const activationEmail = async () => {
      try {
        const res = await axios.post('/user/activation', {
          activationToken,
        });
        toast.success(res.data.msg, configToast);
      } catch (err) {
        err.response.data.msg &&
          toast.error(err.response.data.msg, configToast);
      }
    };
    activationEmail();
  }

  return <div className="active_page"></div>;
};

export default ActivationEmail;
