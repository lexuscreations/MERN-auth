import axios from 'axios';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import Button from '@mui/material/Button';
import { ForwardToInbox as ForwardToInboxIcon } from '@mui/icons-material';

import { isEmpty, isEmail } from '../../utils/validation/Validation';
import config from '../../../config/app.config';

const configToast = config.CONFIG_TOAST;

const initialState = {
  email: '',
};

const ForgotPassword = () => {
  const [data, setData] = useState(initialState);
  const { email } = data;
  const navigate = useNavigate();

  const handleChangeInput = (e) =>
    setData({ ...data, [e.target.name]: e.target.value });

  const forgotPassword = async () => {
    if (isEmpty(email))
      return toast.error('Please Enter Your email.', configToast);

    if (!isEmail(email)) return toast.error('Invalid email.', configToast);

    try {
      const res = await axios.post('/user/forgot', { email });
      return toast.success(res.data.msg, configToast);
    } catch (err) {
      err.response.data.msg && toast.error(err.response.data.msg, configToast);
    }
  };

  useEffect(() => {
    axios.defaults.baseURL = config.REACT_APP_SERVER_URI;
  }, []);

  return (
    <>
      <button onClick={() => navigate(-1)} className="go_back_btn">
        <i className="fas fa-long-arrow-alt-left"></i> Go Back
      </button>
      <div className="d-flex-center" style={{ minHeight: '80vh' }}>
        <div className="authFormContainer">
          <div style={{ padding: '0', width: '340px' }}>
            <h2>Forgot Your Password?</h2>
            <label htmlFor="email">Enter Your Email Address</label>
            <input
              type="email"
              name="email"
              id="email"
              value={email}
              onChange={handleChangeInput}
              placeholder="Email"
              style={{ marginTop: '0.7rem' }}
            />
            <Button
              onClick={forgotPassword}
              variant="contained"
              color="inherit"
              endIcon={<ForwardToInboxIcon />}
            >
              Verify your email
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;
