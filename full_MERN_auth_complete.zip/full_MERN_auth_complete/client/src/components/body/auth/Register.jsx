import axios from 'axios';
import { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { toast } from 'react-toastify';

import Button from '@mui/material/Button';
import { AppRegistrationOutlined as RegisterIcon } from '@mui/icons-material';

import {
  isEmpty,
  isEmail,
  isLength,
  isMatch,
} from '../../utils/validation/Validation';

import config from '../../../config/app.config';
const configToast = config.CONFIG_TOAST;

const initialState = {
  name: '',
  email: '',
  password: '',
  cf_password: '',
};

const Register = () => {
  const [user, setUser] = useState(initialState);
  const { name, email, password, cf_password } = user;

  const handleChangeInput = (e) =>
    setUser({ ...user, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      isEmpty(name) ||
      isEmpty(email) ||
      isEmpty(password) ||
      isEmpty(cf_password)
    )
      return toast.error('Please fill in all fields.', configToast);

    if (!isEmail(email)) return toast.error('Invalid emails.', configToast);

    if (isLength(password))
      return toast.error(
        'Password must be at least 6 characters.',
        configToast
      );

    if (!isMatch(password, cf_password))
      return toast.error(
        'Password and confirm password must be match.',
        configToast
      );

    try {
      const res = await axios.post('/user/register', {
        name,
        email,
        password,
      });

      toast.success(res.data.msg, configToast);
    } catch (err) {
      err.response.data.msg && toast.error(err.response.data.msg, configToast);
    }
  };

  useEffect(() => {
    axios.defaults.baseURL = config.REACT_APP_SERVER_URI;
  }, []);

  return (
    <div className="d-flex-center" style={{ minHeight: '80vh' }}>
      <div className="authFormContainer">
        <h2>Register</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="name">Name</label>
            <input
              type="text"
              placeholder="Enter your name"
              id="name"
              value={name}
              name="name"
              onChange={handleChangeInput}
            />
          </div>

          <div>
            <label htmlFor="email">Email Address</label>
            <input
              type="text"
              placeholder="Enter email address"
              id="email"
              value={email}
              name="email"
              onChange={handleChangeInput}
            />
          </div>

          <div>
            <label htmlFor="password">Password</label>
            <input
              type="password"
              placeholder="Enter password"
              id="password"
              value={password}
              name="password"
              onChange={handleChangeInput}
            />
          </div>

          <div>
            <label htmlFor="cf_password">Confirm Password</label>
            <input
              type="password"
              placeholder="Confirm password"
              id="cf_password"
              value={cf_password}
              name="cf_password"
              onChange={handleChangeInput}
            />
          </div>

          <Button
            type="submit"
            variant="contained"
            color="inherit"
            endIcon={<RegisterIcon />}
          >
            Register
          </Button>
        </form>

        <p style={{ margin: '10px 0' }}>
          Already have an account?{' '}
          <NavLink to="/login" style={{ fontWeight: '600' }}>
            Login
          </NavLink>
        </p>
      </div>
    </div>
  );
};

export default Register;
