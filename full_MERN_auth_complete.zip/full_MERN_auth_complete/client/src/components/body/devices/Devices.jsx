import React from 'react';

const Devices = () => {
  return (
    <>
      <h1>devices</h1>
    </>
  );
};

export default Devices;
