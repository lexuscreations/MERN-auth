import { useSelector } from 'react-redux';
import { Routes, Route } from 'react-router-dom';

import Home from './home/Home';

import Profile from './profile/Profile';
import Devices from './devices/Devices';
import EditUser from './profile/EditUser';

import NotFound from '../utils/NotFound/NotFound';

import Login from './auth/Login';
import Register from './auth/Register';
import ResetPass from './auth/ResetPassword';
import ForgotPass from './auth/ForgotPassword';
import ActivationEmail from './auth/ActivationEmail';

const Body = () => {
  const auth = useSelector((state) => state.auth);
  const { isLogged, isAdmin } = auth;

  return (
    <section>
      <Routes>
        <Route path="/" element={<Home />} exact />

        <Route
          path="/login"
          element={isLogged ? <NotFound /> : <Login />}
          exact
        />

        <Route
          path="/register"
          element={isLogged ? <NotFound /> : <Register />}
          exact
        />

        <Route
          path="/forgot_password"
          element={isLogged ? <NotFound /> : <ForgotPass />}
          exact
        />

        <Route
          path="/user/reset/:token"
          element={isLogged ? <NotFound /> : <ResetPass />}
          exact
        />

        <Route
          path="/user/activate/:activation_token"
          element={<ActivationEmail />}
          exact
        />

        <Route
          path="/profile"
          element={isLogged ? <Profile /> : <NotFound />}
          exact
        />

        <Route
          path="/devices"
          element={isLogged ? <Devices /> : <NotFound />}
          exact
        />

        <Route
          path="/edit_user/:id"
          element={isAdmin ? <EditUser /> : <NotFound />}
          exact
        />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </section>
  );
};

export default Body;
