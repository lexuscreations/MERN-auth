import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Link, NavLink } from 'react-router-dom';
import axios from 'axios';

import config from '../../config/app.config';

const Header = () => {
  const auth = useSelector((state) => state.auth);
  const { user, isLogged } = auth;

  const [headerTitle, setHeaderTitle] = useState('RBI');

  const handleLogout = async () => {
    try {
      await axios.get('/user/logout');
      localStorage.removeItem('firstLogin');
      window.location.href = '/login';
    } catch (err) {
      window.location.href = '/login';
    }
  };

  useEffect(() => {
    axios.defaults.baseURL = config.REACT_APP_SERVER_URI;
    let i = 0;
    const titleTimerInterval = setInterval(() => {
      setHeaderTitle(config.REACT_APP_TITLE[i].shortName);
      i++;
      if (i === 3) i = 0;
    }, 2000);
    return () => {
      clearTimeout(titleTimerInterval);
    };
  }, []);

  const userLink = () => {
    return (
      <li className="drop-nav">
        <NavLink to="#" className="avatar">
          <img src={user.avatar} alt="" /> {user.name}{' '}
          <i className="fas fa-angle-down"></i>
        </NavLink>
        <ul className="dropdown">
          <li>
            <NavLink
              to="/profile"
              className={({ isActive }) => (isActive ? 'active' : 'inactive')}
            >
              Profile
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/devices"
              className={({ isActive }) => (isActive ? 'active' : 'inactive')}
            >
              devices
            </NavLink>
          </li>
          <li>
            <Link to="/" onClick={handleLogout}>
              Logout
            </Link>
          </li>
        </ul>
      </li>
    );
  };

  const transForm = {
    transform: isLogged ? 'translateY(-5px)' : 0,
  };

  return (
    <header className="navbar_header">
      <div className="logo d-flex-center">
        <h3 style={{ marginRight: '1.2rem' }}>
          <NavLink to="/" className="d-flex-center">
            <img src="/images/header_logo192.png" alt="" width="40px" />
            {headerTitle}
          </NavLink>
        </h3>
        <NavLink
          to="/"
          className={({ isActive }) =>
            isActive
              ? 'active homeBtn d-flex-center'
              : 'inactive homeBtn d-flex-center'
          }
        >
          <i
            style={{ color: 'white', cursor: 'pointer' }}
            className="fas fa-home"
          >
            &nbsp;Home
          </i>
        </NavLink>
      </div>

      <ul style={transForm}>
        {isLogged ? (
          userLink()
        ) : (
          <li>
            <NavLink to="/login">
              <i className="fas fa-user"></i> Sign in
            </NavLink>
          </li>
        )}
      </ul>
    </header>
  );
};

export default Header;
