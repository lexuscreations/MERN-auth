const { createSlice } = require('@reduxjs/toolkit');

const userListSlice = createSlice({
  name: 'users',
  initialState: {
    list: [],
  },
  reducers: {
    add(state, action) {
      state.list = action.payload;
    },
  },
});

export const { add } = userListSlice.actions;
export default userListSlice.reducer;
