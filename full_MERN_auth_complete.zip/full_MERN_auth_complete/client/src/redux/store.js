import { configureStore } from '@reduxjs/toolkit';
import userListSlice from './userListSlice';
import authSlice from './authSlice';
import tokenSlice from './tokenSlice';

const store = configureStore({
  reducer: {
    users: userListSlice,
    auth: authSlice,
    token: tokenSlice,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ serializableCheck: false }),
});

export default store;
