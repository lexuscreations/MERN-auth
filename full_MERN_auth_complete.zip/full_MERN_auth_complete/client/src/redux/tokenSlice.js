const { createSlice } = require('@reduxjs/toolkit');

const tokenSlice = createSlice({
  name: 'token',
  initialState: {
    token: '',
  },
  reducers: {
    set(state, action) {
      state.token = action.payload;
    },
  },
});

export const { set } = tokenSlice.actions;
export default tokenSlice.reducer;
