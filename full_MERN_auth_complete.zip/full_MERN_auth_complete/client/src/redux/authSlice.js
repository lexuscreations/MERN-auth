const { createSlice } = require('@reduxjs/toolkit');

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: [],
    isLogged: false,
    isAdmin: false,
  },
  reducers: {
    login(state, action) {
      state.isLogged = true;
    },
    addLoggedUser(state, action) {
      state.user = action.payload.data;
      state.isAdmin = action.payload.data.role === 1 ? true : false;
    },
  },
});

export const { login, addLoggedUser } = authSlice.actions;
export default authSlice.reducer;
