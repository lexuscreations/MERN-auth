import { useEffect } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { ToastContainer } from 'react-toastify';
import config from './config/app.config';
import { login, addLoggedUser } from './redux/authSlice';
import { toast } from 'react-toastify';
import { set } from './redux/tokenSlice';
import Header from './components/header/Header';
import Body from './components/body/Body';
import axios from 'axios';

const configToast = config.CONFIG_TOAST;
axios.defaults.baseURL = config.REACT_APP_SERVER_URI;

const App = () => {
  const dispatch = useDispatch();
  const { token } = useSelector((state) => state.token);
  const auth = useSelector((state) => state.auth);

  useEffect(() => {
    const firstLogin = localStorage.getItem('firstLogin');
    if (firstLogin) {
      const getToken = async () => {
        try {
          const res = await axios.post(`/user/refresh_token`, {
            token: localStorage.getItem('token'),
          });
          dispatch(set(res.data.accessToken));
        } catch (error) {
          toast.error(
            (error.response &&
              error.response.data &&
              error.response.data.msg) ||
              error.message,
            configToast
          );
        }
      };
      getToken();
    }
  }, [auth.isLogged, dispatch]);

  useEffect(() => {
    if (token) {
      const getUser = () => {
        dispatch(login());
        (async () => {
          const res = await axios.get(`/user/infor`, {
            headers: { Authorization: token },
          });
          dispatch(addLoggedUser(res));
        })();
      };
      getUser();
    }
  }, [token, dispatch]);

  useEffect(() => {
    let i = 0;
    setInterval(() => {
      document.title = config.REACT_APP_TITLE[i].fullName;
      i++;
      if (i === 3) i = 0;
    }, 2000);
  }, []);

  return (
    <Router>
      <div className="App">
        <Header />
        <Body />
        <ToastContainer
          position="top-right"
          autoClose={5000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
        />
      </div>
    </Router>
  );
};

export default App;
